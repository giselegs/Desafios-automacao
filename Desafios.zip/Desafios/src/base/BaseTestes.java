package base;


import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import paginas.Login;

//import pages.HomePage;

public class BaseTestes  {
	private static WebDriver driver;
	protected static Login login;
	
	@BeforeClass
	public static void setUp(){
		System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://mantis-prova.base2.com.br/my_view_page.php");
		
		login = new Login(driver);
	}
	/*@AfterClass
	public void dearDown(){
		driver.quit();
	}*/
	

}
