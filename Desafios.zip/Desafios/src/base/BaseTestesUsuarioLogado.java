package base;

import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import paginas.Login;
import paginas.MinhaVisao;

public class BaseTestesUsuarioLogado {
	private static WebDriver driver;
	protected static Login login;
	protected static MinhaVisao myview;
	
	@BeforeClass
	public static void setUp(){
		System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://mantis-prova.base2.com.br/login_page.php");
		
		login.setNome("Gisele.Germano");
		login.setSenha("qwertyABC08");
		login.clicarBotaoLogin();
		
		myview = new MinhaVisao(driver);
		
	}

	public static void main (String[] args){
		BaseTestesUsuarioLogado testelogado = new BaseTestesUsuarioLogado();
		testelogado.setUp();
		
	}

}
