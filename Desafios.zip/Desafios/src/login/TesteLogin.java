package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.junit.Test.*;
import org.junit.Assert.*;
import static org.junit.Assert.*;
import org.junit.Test;
import paginas.Login;

public class TesteLogin  {
	
	private WebDriver driver;
	private By msgAlerta = By.tagName("font");
	
	public TesteLogin(WebDriver driver){
		this.driver = driver;
	}
	
	@Test
	public void loginComSucesso(){
		Login login = new Login(driver);
		
		login.setNome("Gisele.Germano");
		login.setSenha("qwertyABC08");
		login.clicarBotaoLogin();
		assertEquals("https://mantis-prova.base2.com.br/my_view_page.php", driver.getCurrentUrl());	
	}
	
	@Test
	public void loginCamposVazios(){
		Login login = new Login(driver);
		login.clicarBotaoLogin();
		assertEquals("Your account may be disabled or blocked or the username/password you entered is incorrect.", driver.findElement(msgAlerta));
	}
	
	@Test
	public void loginUsuarioIncorreto(){
		Login login = new Login(driver);
		
		login.setNome("Gisele.Silva");
		login.setSenha("qwertyABC08");
		login.clicarBotaoLogin();
		assertEquals("Your account may be disabled or blocked or the username/password you entered is incorrect.", driver.findElement(msgAlerta));	
	}
	
	@Test
	public void loginSenhaIncorreta(){
		Login login = new Login(driver);
		
		login.setNome("Gisele.Germano");
		login.setSenha("08ABCqwerty");
		login.clicarBotaoLogin();
		assertEquals("Your account may be disabled or blocked or the username/password you entered is incorrect.", driver.findElement(msgAlerta));	
	}

	@Test
	public void esqueceuSenha(){
		Login login = new Login(driver);
		
		login.clicarLinkForgotPassword();
		assertEquals("https://mantis-prova.base2.com.br/lost_pwd_page.php", driver.getCurrentUrl());
		
	}
}
