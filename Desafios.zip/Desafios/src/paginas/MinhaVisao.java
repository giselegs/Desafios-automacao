package paginas;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MinhaVisao {
	private WebDriver driver;
	private By ReportIssueLink = By.linkText("Report Issue");
	
	public MinhaVisao(WebDriver driver){
		this.driver = driver;
	}
	
	public SelecionaProjeto clicarLinkReportIssue(){
		driver.findElement(ReportIssueLink).click();
		return new SelecionaProjeto(driver);
	}

}
