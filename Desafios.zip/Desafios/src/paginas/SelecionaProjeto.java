package paginas;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class SelecionaProjeto {
	
	private WebDriver driver;
	private By checkbox = By.cssSelector("#category project_id");
	
	
	public SelecionaProjeto(WebDriver driver){
		this.driver = driver;
	}
	
	public void selecionar(String option){
		Select itemSelecionado = new Select(driver.findElement(checkbox));
		itemSelecionado.selectByVisibleText(option);
		
		
		
	}
	
	

}
