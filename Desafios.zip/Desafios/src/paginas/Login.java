package paginas;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import base.BaseTestes;


public class Login {
	private WebDriver driver;
	private By nomeUsuario = By.id("username");
	private By senhaUsuario = By.id("password");
	private By botaoLogin = By.cssSelector("#login_form button");
	private By linkEsqueceuSenha = By.tagName("a");
	
	
	
	public Login(WebDriver driver){
		this.driver = driver;
	}
	
	public void setNome(String nome){
		driver.findElement(nomeUsuario).sendKeys(nome);
	}
	
	public void setSenha(String senha){
		driver.findElement(senhaUsuario).sendKeys(senha);
	}
	
	public void clicarBotaoLogin(){
		driver.findElement(botaoLogin).click();
	}
	
	public void clicarLinkForgotPassword(){
		driver.findElement(linkEsqueceuSenha).click();
	}
	
	/*public BaseTestes acionarPagina(){
		driver.getCurrentUrl();
		return new BaseTestes();
	}*/
}
